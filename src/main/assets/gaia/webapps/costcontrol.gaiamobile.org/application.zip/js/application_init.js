/* global CostControlApp */
'use strict';

CostControlApp.init();
