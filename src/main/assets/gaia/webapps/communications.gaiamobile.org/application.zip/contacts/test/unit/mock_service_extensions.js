'use strict';

/* exported MockExtServices */

var MockExtServices = {
  importGmail: function() {},
  importLive: function() {}
};
