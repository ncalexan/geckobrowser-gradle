'use strict';
/* exported MockContactsTag */

var MockContactsTag = {
  filterTags: function (type, currentNode, tags) {
    return tags;
  },
  setCustomTag: function (element) {},
  setCustomTagVisibility: function (value) {},
  fillTagOptions: function (target, _originalTag, options) {}
};
