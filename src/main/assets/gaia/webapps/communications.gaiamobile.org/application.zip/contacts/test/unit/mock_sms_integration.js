'use strict';
/* exported MockSmsIntegration */

var MockSmsIntegration = {
  sendSms: function (number) {}
};
