'use strict';
/* global MockNavigationStack */
/* exported MockMainNavigation */

var MockMainNavigation = new MockNavigationStack();
