// Alias for 'utf7', could alternately be in our RequireJS config.
define(['./utf7'], function(utf7) {
  return utf7;
});
