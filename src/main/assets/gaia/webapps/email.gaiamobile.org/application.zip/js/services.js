// This file is overwritten by the build process to include final build
// credentials either from /build/services.json or from a distribution-specific
// file. A default is provided here so code will run in a non-build mode.
define({
  oauth2: {
    google: {
      clientId:
     '673813704507-oenvl6ani4lmro5v9v934t18smabl12e.apps.googleusercontent.com',
      clientSecret: 'RzT95HkzNNwEHFdxYbYpqYTN'
    }
  }
});
