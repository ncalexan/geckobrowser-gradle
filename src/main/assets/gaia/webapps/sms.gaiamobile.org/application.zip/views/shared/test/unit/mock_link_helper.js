/*exported MockLinkHelper */

'use strict';

var MockLinkHelper = {
  searchAndLinkClickableData: function(input) {
    return input;
  }
};
