/*exported MockMozPhoneNumberService */
'use strict';

var MockMozPhoneNumberService = {
  normalize: function nmpns_normalize() {
    return true;
  },
  fuzzyMatch: function nmpns_fuzzyMatch() {
  }
};
