/*exported MockInterInstanceEventDispatcher */

'use strict';

function MockInterInstanceEventDispatcher() {}

MockInterInstanceEventDispatcher.on = () => {};
MockInterInstanceEventDispatcher.emit = () => {};
MockInterInstanceEventDispatcher.connect = () => {};
MockInterInstanceEventDispatcher.disconnect = () => {};
