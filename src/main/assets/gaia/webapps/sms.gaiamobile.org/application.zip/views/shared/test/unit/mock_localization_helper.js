/*exported MockLocalizationHelper*/

(function(exports) {
  'use strict';

  exports.MockLocalizationHelper = {
    init: () => {}
  };
})(window);
