/*exported MockVibrate */

'use strict';

function MockVibrate() {}
