/*exported MockLinkActionHandler */

'use strict';

var MockLinkActionHandler = {
  onContextMenu: function() {},
  onClick: function() {}
};
