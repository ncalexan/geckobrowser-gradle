/* global Startup */

'use strict';

Startup.init();
