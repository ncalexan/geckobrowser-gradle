/* exported MockApp */

(function(exports) {
  'use strict';

  exports.MockApp = {
    whenReady: () => Promise.resolve()
  };
})(window);
