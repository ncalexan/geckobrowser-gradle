/*exported MockSubjectComposer */

'use strict';

function MockSubjectComposer() {}

MockSubjectComposer.prototype.setValue = () => {};
MockSubjectComposer.prototype.getValue = () => {};
MockSubjectComposer.prototype.isVisible = () => {};
MockSubjectComposer.prototype.reset = () => {};
MockSubjectComposer.prototype.show = () => {};
MockSubjectComposer.prototype.hide = () => {};
MockSubjectComposer.prototype.toggle = () => {};
MockSubjectComposer.prototype.focus = () => {};
MockSubjectComposer.prototype.getMaxLength = () => {};
MockSubjectComposer.prototype.on = () => {};
