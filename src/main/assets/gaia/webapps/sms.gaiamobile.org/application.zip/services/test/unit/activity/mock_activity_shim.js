/* exported MockActivityShim */

(function(exports) {
  'use strict';

  exports.MockActivityShim = {
    init: () => {},
    hasPendingRequest: () => false
  };
})(window);
